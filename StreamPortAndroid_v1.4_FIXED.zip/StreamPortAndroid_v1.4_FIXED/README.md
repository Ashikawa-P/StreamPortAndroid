# StreamPort Android v1.4

This version corrects segment discovery while retaining the playback fixes
introduced in v1.3.

Fixes:
- Segment 300 is used only as a search anchor.
- If 300 is absent, probing moves downward in blocks of 50.
- From the first valid anchor, probing moves upward to the exact final segment.
- The HLS playlist always contains the complete range from segment 0 to the
  discovered final segment.
- Segment validation uses a ranged GET.
- Media requests include User-Agent, Referer and Origin.
- Playback starts explicitly and ExoPlayer errors are shown in the UI.
