# StreamPort Android v2.0

Version 2.0 no longer attempts to imitate the working HTML with ExoPlayer.

Instead, it embeds the original hls.js playback model in Android WebView:

1. The supplied SkillUncapped HTML algorithm finds the final segment using
   HEAD requests.
2. It builds the same in-memory HLS playlist from segment 0 through the final
   segment.
3. hls.js loads and transmuxes the MPEG-TS fragments in the WebView.
4. A narrowly scoped WebViewClient intercepts only the configured CloudFront
   host.
5. It forwards GET and HEAD without fabricated Origin, Referer, cookies or
   credentials.
6. It adds Access-Control-Allow-Origin only to the response, reproducing what
   the browser CORS-disabler extension did.

No arbitrary URLs are proxied. The interceptor is limited to:
d13z5uuzt1wkbz.cloudfront.net
