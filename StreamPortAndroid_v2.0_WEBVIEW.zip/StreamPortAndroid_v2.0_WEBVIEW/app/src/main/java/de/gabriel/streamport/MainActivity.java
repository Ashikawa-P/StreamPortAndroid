package de.gabriel.streamport;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final String APP_ORIGIN = "https://app.local";
    private static final String CDN_HOST =
            "d13z5uuzt1wkbz.cloudfront.net";

    private WebView webView;

    @Override
    @SuppressLint("SetJavaScriptEnabled")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        String browserUserAgent = settings.getUserAgentString();

        webView.setWebViewClient(
                new CdnCorsWebViewClient(browserUserAgent)
        );

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                return true;
            }
        });

        try {
            String html = readAsset("player.html");
            webView.loadDataWithBaseURL(
                    APP_ORIGIN + "/",
                    html,
                    "text/html",
                    "UTF-8",
                    null
            );
        } catch (IOException exception) {
            Toast.makeText(
                    this,
                    "Player konnte nicht geladen werden: "
                            + exception.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private String readAsset(String name) throws IOException {
        try (InputStream input = getAssets().open(name)) {
            byte[] buffer = new byte[8192];
            StringBuilder result = new StringBuilder();
            int count;

            while ((count = input.read(buffer)) != -1) {
                result.append(
                        new String(
                                buffer,
                                0,
                                count,
                                StandardCharsets.UTF_8
                        )
                );
            }
            return result.toString();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.destroy();
        }
        super.onDestroy();
    }

    private static final class CdnCorsWebViewClient
            extends WebViewClient {
        private final String userAgent;

        CdnCorsWebViewClient(String userAgent) {
            this.userAgent = userAgent;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(
                WebView view,
                WebResourceRequest request
        ) {
            String host = request.getUrl().getHost();
            if (host == null
                    || !CDN_HOST.equalsIgnoreCase(host)) {
                return null;
            }

            return proxyCdnRequest(request);
        }

        private WebResourceResponse proxyCdnRequest(
                WebResourceRequest request
        ) {
            HttpURLConnection connection = null;

            try {
                String method =
                        request.getMethod().toUpperCase(Locale.ROOT);

                if ("OPTIONS".equals(method)) {
                    return emptyCorsResponse(204, "No Content");
                }

                if (!"GET".equals(method)
                        && !"HEAD".equals(method)) {
                    return errorResponse(
                            405,
                            "Method Not Allowed",
                            "Nicht unterstützte Methode: " + method
                    );
                }

                connection = (HttpURLConnection)
                        new URL(request.getUrl().toString())
                                .openConnection();

                connection.setRequestMethod(method);
                connection.setInstanceFollowRedirects(true);
                connection.setConnectTimeout(15_000);
                connection.setReadTimeout(30_000);
                connection.setUseCaches(false);

                /*
                 * Reproduce the successful browser request, not the previous
                 * ExoPlayer request:
                 *
                 * - no fabricated Origin header;
                 * - no fabricated Referer header;
                 * - no cookies or credentials;
                 * - HEAD remains HEAD;
                 * - GET remains a normal browser-like GET.
                 *
                 * The missing CORS permission is added only to the response,
                 * exactly like a browser CORS-disabler extension does.
                 */
                connection.setRequestProperty(
                        "User-Agent",
                        userAgent
                );
                connection.setRequestProperty(
                        "Accept",
                        request.getRequestHeaders()
                                .getOrDefault("Accept", "*/*")
                );
                connection.setRequestProperty(
                        "Accept-Encoding",
                        "identity"
                );

                String range =
                        request.getRequestHeaders().get("Range");
                if (range != null && !range.isEmpty()) {
                    connection.setRequestProperty("Range", range);
                }

                int statusCode = connection.getResponseCode();
                String reason = safeReason(
                        statusCode,
                        connection.getResponseMessage()
                );

                Map<String, String> responseHeaders =
                        copyResponseHeaders(connection);
                addCorsHeaders(responseHeaders);

                String mimeType = determineMimeType(
                        connection.getContentType(),
                        request.getUrl().toString()
                );

                if ("HEAD".equals(method)
                        || statusCode == 204
                        || statusCode == 304) {
                    connection.disconnect();
                    return new WebResourceResponse(
                            mimeType,
                            null,
                            statusCode,
                            reason,
                            responseHeaders,
                            new ByteArrayInputStream(new byte[0])
                    );
                }

                InputStream body;
                if (statusCode >= 400) {
                    body = connection.getErrorStream();
                } else {
                    body = connection.getInputStream();
                }

                if (body == null) {
                    body = new ByteArrayInputStream(new byte[0]);
                }

                return new WebResourceResponse(
                        mimeType,
                        null,
                        statusCode,
                        reason,
                        responseHeaders,
                        new DisconnectingInputStream(body, connection)
                );
            } catch (Exception exception) {
                if (connection != null) {
                    connection.disconnect();
                }

                return errorResponse(
                        502,
                        "Bad Gateway",
                        exception.getClass().getSimpleName()
                                + ": " + exception.getMessage()
                );
            }
        }

        private WebResourceResponse emptyCorsResponse(
                int statusCode,
                String reason
        ) {
            Map<String, String> headers = new LinkedHashMap<>();
            addCorsHeaders(headers);

            return new WebResourceResponse(
                    "text/plain",
                    "UTF-8",
                    statusCode,
                    reason,
                    headers,
                    new ByteArrayInputStream(new byte[0])
            );
        }

        private WebResourceResponse errorResponse(
                int statusCode,
                String reason,
                String message
        ) {
            Map<String, String> headers = new LinkedHashMap<>();
            addCorsHeaders(headers);

            return new WebResourceResponse(
                    "text/plain",
                    "UTF-8",
                    statusCode,
                    reason,
                    headers,
                    new ByteArrayInputStream(
                            message.getBytes(StandardCharsets.UTF_8)
                    )
            );
        }

        private Map<String, String> copyResponseHeaders(
                HttpURLConnection connection
        ) {
            Map<String, String> result = new LinkedHashMap<>();

            for (Map.Entry<String, List<String>> entry
                    : connection.getHeaderFields().entrySet()) {
                String name = entry.getKey();
                List<String> values = entry.getValue();

                if (name == null
                        || values == null
                        || values.isEmpty()
                        || isHopByHopHeader(name)) {
                    continue;
                }

                result.put(name, String.join(", ", values));
            }

            return result;
        }

        private boolean isHopByHopHeader(String name) {
            String normalized = name.toLowerCase(Locale.ROOT);

            return normalized.equals("connection")
                    || normalized.equals("keep-alive")
                    || normalized.equals("proxy-authenticate")
                    || normalized.equals("proxy-authorization")
                    || normalized.equals("te")
                    || normalized.equals("trailers")
                    || normalized.equals("transfer-encoding")
                    || normalized.equals("upgrade")
                    || normalized.equals("content-encoding");
        }

        private void addCorsHeaders(Map<String, String> headers) {
            headers.put(
                    "Access-Control-Allow-Origin",
                    APP_ORIGIN
            );
            headers.put(
                    "Access-Control-Allow-Methods",
                    "GET, HEAD, OPTIONS"
            );
            headers.put(
                    "Access-Control-Allow-Headers",
                    "Range, Accept, Content-Type"
            );
            headers.put(
                    "Access-Control-Expose-Headers",
                    "Content-Length, Content-Range, Accept-Ranges, ETag"
            );
            headers.put("Vary", "Origin");
        }

        private String determineMimeType(
                String contentType,
                String url
        ) {
            if (contentType != null
                    && !contentType.trim().isEmpty()) {
                int separator = contentType.indexOf(';');
                return separator >= 0
                        ? contentType.substring(0, separator).trim()
                        : contentType.trim();
            }

            if (url.toLowerCase(Locale.ROOT).endsWith(".ts")) {
                return "video/mp2t";
            }

            return "application/octet-stream";
        }

        private String safeReason(
                int statusCode,
                String reason
        ) {
            if (reason != null
                    && !reason.trim().isEmpty()
                    && reason.chars().allMatch(
                            character -> character >= 32
                                    && character <= 126
                    )) {
                return reason;
            }

            switch (statusCode) {
                case 200:
                    return "OK";
                case 204:
                    return "No Content";
                case 206:
                    return "Partial Content";
                case 301:
                    return "Moved Permanently";
                case 302:
                    return "Found";
                case 304:
                    return "Not Modified";
                case 400:
                    return "Bad Request";
                case 403:
                    return "Forbidden";
                case 404:
                    return "Not Found";
                case 405:
                    return "Method Not Allowed";
                case 416:
                    return "Range Not Satisfiable";
                case 500:
                    return "Internal Server Error";
                case 502:
                    return "Bad Gateway";
                default:
                    return "HTTP " + statusCode;
            }
        }
    }

    private static final class DisconnectingInputStream
            extends FilterInputStream {
        private final HttpURLConnection connection;

        DisconnectingInputStream(
                InputStream input,
                HttpURLConnection connection
        ) {
            super(input);
            this.connection = connection;
        }

        @Override
        public void close() throws IOException {
            try {
                super.close();
            } finally {
                connection.disconnect();
            }
        }
    }
}
