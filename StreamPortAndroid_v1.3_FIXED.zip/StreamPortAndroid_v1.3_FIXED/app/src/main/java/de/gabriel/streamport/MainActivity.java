package de.gabriel.streamport;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.util.MimeTypes;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final Pattern VIDEO_ID_REGEX = Pattern.compile(
            "([a-z0-9]{10})(?:/|\\?|$)", Pattern.CASE_INSENSITIVE);

    private static final String CDN_ROOT =
            "https://d13z5uuzt1wkbz.cloudfront.net";
    private static final String SITE_ORIGIN =
            "https://www.skill-capped.com";
    private static final String REFERER =
            "https://www.skill-capped.com/";
    private static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 "
                    + "Chrome/149 Mobile Safari/537.36";

    /*
     * The supplied browser implementation begins probing at segment 300.
     * These streams therefore must not be reconstructed as if segment 0
     * were necessarily the first playable segment.
     */
    private static final int PREFERRED_FIRST_SEGMENT = 300;
    private static final int MAXIMUM_SEGMENT = 5000;

    private EditText urlInput;
    private Button streamButton;
    private TextView statusText;
    private ProgressBar progressBar;
    private PlayerView playerView;
    private ExoPlayer player;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean isLoading = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        streamButton = findViewById(R.id.streamButton);
        statusText = findViewById(R.id.statusText);
        progressBar = findViewById(R.id.progressBar);
        playerView = findViewById(R.id.playerView);

        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        playerView.setControllerAutoShow(true);
        playerView.showController();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                String detail = error.getMessage();
                if (detail == null || detail.trim().isEmpty()) {
                    detail = "Unbekannter Playerfehler";
                }
                statusText.setText("Wiedergabefehler: " + detail);
                Toast.makeText(
                        MainActivity.this,
                        "Wiedergabe fehlgeschlagen: " + detail,
                        Toast.LENGTH_LONG
                ).show();
                playerView.showController();
            }
        });

        streamButton.setOnClickListener(view -> startStream());
        urlInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) {
                startStream();
                return true;
            }
            return false;
        });
    }

    private void startStream() {
        if (!isLoading.compareAndSet(false, true)) {
            return;
        }

        String rawUrl = urlInput.getText().toString().trim();
        if (rawUrl.isEmpty()) {
            finishLoading("Bitte eine URL eingeben.");
            return;
        }

        setLoadingUi(true, "Verarbeite URL …");

        if (rawUrl.toLowerCase(Locale.ROOT).contains(".m3u8")) {
            playHls(Uri.parse(rawUrl));
            finishLoading("Stream wird geladen.");
            return;
        }

        String videoId = extractVideoId(rawUrl);
        if (videoId == null) {
            finishLoading("Keine gültige zehnstellige Video-ID gefunden.");
            return;
        }

        worker.execute(() -> {
            try {
                int firstSegment = findFirstPlayableSegment(videoId);
                int lastSegment = findLastSegment(videoId, firstSegment);
                File playlistFile =
                        createPlaylist(videoId, firstSegment, lastSegment);

                runOnUiThread(() -> {
                    playHls(Uri.fromFile(playlistFile));
                    int count = lastSegment - firstSegment + 1;
                    finishLoading(
                            "Gefunden: " + count + " Segmente ("
                                    + firstSegment + "–" + lastSegment + ")."
                    );
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    String message = exception.getMessage() == null
                            ? "Unbekannter Fehler"
                            : exception.getMessage();
                    finishLoading("Fehler: " + message);
                    Toast.makeText(
                            MainActivity.this,
                            "Stream konnte nicht geladen werden: " + message,
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private String extractVideoId(String rawUrl) {
        Matcher matcher = VIDEO_ID_REGEX.matcher(rawUrl);
        List<String> ids = new ArrayList<>();
        while (matcher.find()) {
            ids.add(matcher.group(1));
        }
        if (ids.isEmpty()) {
            return null;
        }
        return rawUrl.toLowerCase(Locale.ROOT).contains("browse3")
                ? ids.get(0)
                : ids.get(ids.size() - 1);
    }

    private int findFirstPlayableSegment(String videoId) throws IOException {
        if (segmentExists(videoId, PREFERRED_FIRST_SEGMENT)) {
            return PREFERRED_FIRST_SEGMENT;
        }

        /*
         * Fallback for unusual videos. Search below the normal anchor first,
         * because short videos can end before segment 300.
         */
        for (int index = PREFERRED_FIRST_SEGMENT - 1; index >= 0; index--) {
            if (segmentExists(videoId, index)) {
                return index;
            }
        }

        for (int index = PREFERRED_FIRST_SEGMENT + 1;
             index <= MAXIMUM_SEGMENT;
             index++) {
            if (segmentExists(videoId, index)) {
                return index;
            }
        }

        throw new IOException("Keine abspielbaren Videosegmente gefunden.");
    }

    private int findLastSegment(String videoId, int knownPresent)
            throws IOException {
        int low = knownPresent;
        int high = knownPresent + 100;

        while (high <= MAXIMUM_SEGMENT && segmentExists(videoId, high)) {
            low = high;
            high += 100;
        }

        if (high > MAXIMUM_SEGMENT) {
            if (segmentExists(videoId, MAXIMUM_SEGMENT)) {
                throw new IOException(
                        "Kein Streamende bis Segment "
                                + MAXIMUM_SEGMENT + " gefunden."
                );
            }
            high = MAXIMUM_SEGMENT;
        }

        while (low + 1 < high) {
            int middle = low + (high - low) / 2;
            if (segmentExists(videoId, middle)) {
                low = middle;
            } else {
                high = middle;
            }
        }
        return low;
    }

    private boolean segmentExists(String videoId, int index)
            throws IOException {
        updateStatus("Prüfe Segment " + index + " …");

        /*
         * Validate the same request type the player later needs. A tiny ranged
         * GET prevents false positives where HEAD succeeds but media GET fails.
         */
        return requestExists(segmentUrl(videoId, index));
    }

    private boolean requestExists(String url) throws IOException {
        HttpURLConnection connection =
                (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(10_000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Referer", REFERER);
            connection.setRequestProperty("Origin", SITE_ORIGIN);
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Range", "bytes=0-0");

            int responseCode = connection.getResponseCode();
            if (responseCode >= 200 && responseCode <= 399) {
                return true;
            }
            if (responseCode == HttpURLConnection.HTTP_FORBIDDEN
                    || responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                return false;
            }
            if (responseCode >= 500 && responseCode <= 599) {
                throw new IOException("Serverfehler HTTP " + responseCode);
            }
            return false;
        } finally {
            connection.disconnect();
        }
    }

    private File createPlaylist(
            String videoId,
            int firstSegment,
            int lastSegment
    ) throws IOException {
        StringBuilder playlist = new StringBuilder();
        playlist.append("#EXTM3U\n");
        playlist.append("#EXT-X-VERSION:3\n");
        playlist.append("#EXT-X-PLAYLIST-TYPE:VOD\n");
        playlist.append("#EXT-X-TARGETDURATION:10\n");
        playlist.append("#EXT-X-MEDIA-SEQUENCE:")
                .append(firstSegment)
                .append('\n');

        /*
         * Critical fix: start with the first segment that actually exists.
         * The previous build always inserted segment 0, so ExoPlayer could
         * calculate a duration but failed as soon as playback requested the
         * first nonexistent file.
         */
        for (int index = firstSegment; index <= lastSegment; index++) {
            playlist.append("#EXTINF:10.0,\n");
            playlist.append(segmentUrl(videoId, index)).append('\n');
        }
        playlist.append("#EXT-X-ENDLIST\n");

        File output = new File(getCacheDir(), "generated-stream.m3u8");
        try (FileOutputStream stream = new FileOutputStream(output)) {
            stream.write(
                    playlist.toString().getBytes(StandardCharsets.UTF_8)
            );
        }
        return output;
    }

    private void playHls(Uri uri) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Referer", REFERER);
        headers.put("Origin", SITE_ORIGIN);
        headers.put("Accept", "*/*");

        DefaultHttpDataSource.Factory httpFactory =
                new DefaultHttpDataSource.Factory()
                        .setUserAgent(USER_AGENT)
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(15_000)
                        .setReadTimeoutMs(15_000)
                        .setDefaultRequestProperties(headers);

        MediaItem mediaItem = new MediaItem.Builder()
                .setUri(uri)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build();

        DefaultDataSource.Factory dataSourceFactory =
                new DefaultDataSource.Factory(this, httpFactory);
        HlsMediaSource mediaSource =
                new HlsMediaSource.Factory(dataSourceFactory)
                        .createMediaSource(mediaItem);

        player.stop();
        player.clearMediaItems();
        player.setMediaSource(mediaSource);
        player.prepare();
        player.play();
        playerView.showController();
    }

    private String segmentUrl(String videoId, int index) {
        return CDN_ROOT + "/" + videoId + "/HIDDEN4500-"
                + String.format(Locale.ROOT, "%05d", index) + ".ts";
    }

    private void updateStatus(String message) {
        runOnUiThread(() -> statusText.setText(message));
    }

    private void setLoadingUi(boolean loading, String message) {
        streamButton.setEnabled(!loading);
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        statusText.setText(message);
    }

    private void finishLoading(String message) {
        isLoading.set(false);
        setLoadingUi(false, message);
    }

    @Override
    protected void onDestroy() {
        playerView.setPlayer(null);
        player.release();
        worker.shutdownNow();
        super.onDestroy();
    }
}
