# StreamPort Android v1.3

This build fixes playback after stream discovery.

Key fixes:
- Uses ExoPlayer 2.19.1 `upstream` imports.
- Starts the generated HLS playlist at the first actually playable segment
  instead of always inserting segment 0.
- Validates segments with a one-byte ranged GET.
- Sends User-Agent, Referer and Origin headers for media requests.
- Starts playback explicitly and reports ExoPlayer playback errors in the UI.
