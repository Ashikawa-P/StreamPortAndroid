package de.gabriel.streamport;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.DefaultRenderersFactory;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.PlaybackException;
import com.google.android.exoplayer2.extractor.ts.DefaultTsPayloadReaderFactory;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.hls.DefaultHlsExtractorFactory;
import com.google.android.exoplayer2.source.hls.HlsMediaSource;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DefaultDataSource;
import com.google.android.exoplayer2.upstream.DefaultHttpDataSource;
import com.google.android.exoplayer2.util.MimeTypes;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class MainActivity extends Activity {
    private static final Pattern VIDEO_ID_REGEX = Pattern.compile(
            "([a-z0-9]{10})(?:/|\\?|$)", Pattern.CASE_INSENSITIVE);

    private static final String CDN_ROOT =
            "https://d13z5uuzt1wkbz.cloudfront.net";
    private static final String SITE_ORIGIN =
            "https://www.skill-capped.com";
    private static final String REFERER =
            "https://www.skill-capped.com/";
    private static final String USER_AGENT =
            "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 "
                    + "Chrome/149 Mobile Safari/537.36";

    /*
     * The original browser implementation starts at 300 only to locate an
     * existing anchor efficiently. The finished playlist still contains the
     * full video from segment 0 through the discovered final segment.
     */
    private static final int PROBE_START_SEGMENT = 300;
    private static final int PROBE_STEP = 50;
    private static final int MAXIMUM_SEGMENT = 5000;

    private EditText urlInput;
    private Button streamButton;
    private TextView statusText;
    private ProgressBar progressBar;
    private PlayerView playerView;
    private ExoPlayer player;

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicBoolean isLoading = new AtomicBoolean(false);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlInput = findViewById(R.id.urlInput);
        streamButton = findViewById(R.id.streamButton);
        statusText = findViewById(R.id.statusText);
        progressBar = findViewById(R.id.progressBar);
        playerView = findViewById(R.id.playerView);

        DefaultRenderersFactory renderersFactory =
                new DefaultRenderersFactory(this)
                        .setEnableDecoderFallback(true);
        player = new ExoPlayer.Builder(this, renderersFactory).build();
        playerView.setPlayer(player);
        playerView.setControllerAutoShow(true);
        playerView.showController();

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException error) {
                String detail = describePlaybackError(error);
                statusText.setText("Wiedergabefehler: " + detail);
                Toast.makeText(
                        MainActivity.this,
                        "Wiedergabe fehlgeschlagen: " + detail,
                        Toast.LENGTH_LONG
                ).show();
                playerView.showController();
            }
        });

        streamButton.setOnClickListener(view -> startStream());
        urlInput.setOnEditorActionListener((view, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_GO) {
                startStream();
                return true;
            }
            return false;
        });
    }

    private void startStream() {
        if (!isLoading.compareAndSet(false, true)) {
            return;
        }

        String rawUrl = urlInput.getText().toString().trim();
        if (rawUrl.isEmpty()) {
            finishLoading("Bitte eine URL eingeben.");
            return;
        }

        setLoadingUi(true, "Verarbeite URL …");

        if (rawUrl.toLowerCase(Locale.ROOT).contains(".m3u8")) {
            playHls(Uri.parse(rawUrl));
            finishLoading("Stream wird geladen.");
            return;
        }

        String videoId = extractVideoId(rawUrl);
        if (videoId == null) {
            finishLoading("Keine gültige zehnstellige Video-ID gefunden.");
            return;
        }

        worker.execute(() -> {
            try {
                int lastSegment = findLastSegment(videoId);
                File playlistFile = createPlaylist(videoId, lastSegment);

                runOnUiThread(() -> {
                    playHls(Uri.fromFile(playlistFile));
                    finishLoading(
                            "Gefunden: " + (lastSegment + 1)
                                    + " Segmente (0–" + lastSegment + ")."
                    );
                });
            } catch (Exception exception) {
                runOnUiThread(() -> {
                    String message = exception.getMessage() == null
                            ? "Unbekannter Fehler"
                            : exception.getMessage();
                    finishLoading("Fehler: " + message);
                    Toast.makeText(
                            MainActivity.this,
                            "Stream konnte nicht geladen werden: " + message,
                            Toast.LENGTH_LONG
                    ).show();
                });
            }
        });
    }

    private String extractVideoId(String rawUrl) {
        Matcher matcher = VIDEO_ID_REGEX.matcher(rawUrl);
        List<String> ids = new ArrayList<>();
        while (matcher.find()) {
            ids.add(matcher.group(1));
        }
        if (ids.isEmpty()) {
            return null;
        }
        return rawUrl.toLowerCase(Locale.ROOT).contains("browse3")
                ? ids.get(0)
                : ids.get(ids.size() - 1);
    }

    private int findLastSegment(String videoId) throws IOException {
        /*
         * Segment 300 is only a search anchor. If it is absent, step downward
         * in blocks of 50 until a known existing segment is found. Then walk
         * upward one segment at a time to determine the exact final segment.
         *
         * Example: if a video ends at 137, probes are 300, 250, 200, 150,
         * 100 (present), followed by 101 ... 137 (present), 138 (missing).
         * The resulting playlist is 0 ... 137, not merely 137 ... 137.
         */
        int anchor = -1;

        if (segmentExists(videoId, PROBE_START_SEGMENT)) {
            anchor = PROBE_START_SEGMENT;
        } else {
            for (int candidate = PROBE_START_SEGMENT - PROBE_STEP;
                 candidate >= 0;
                 candidate -= PROBE_STEP) {
                if (segmentExists(videoId, candidate)) {
                    anchor = candidate;
                    break;
                }
            }
        }

        if (anchor < 0) {
            throw new IOException("Keine abspielbaren Videosegmente gefunden.");
        }

        int lastPresent = anchor;
        for (int candidate = anchor + 1;
             candidate <= MAXIMUM_SEGMENT;
             candidate++) {
            if (!segmentExists(videoId, candidate)) {
                return lastPresent;
            }
            lastPresent = candidate;
        }

        throw new IOException(
                "Kein Streamende bis Segment "
                        + MAXIMUM_SEGMENT + " gefunden."
        );
    }

    private boolean segmentExists(String videoId, int index)
            throws IOException {
        updateStatus("Prüfe Segment " + index + " …");

        /*
         * Validate the same request type the player later needs. A tiny ranged
         * GET prevents false positives where HEAD succeeds but media GET fails.
         */
        return requestExists(segmentUrl(videoId, index));
    }

    private boolean requestExists(String url) throws IOException {
        HttpURLConnection connection =
                (HttpURLConnection) new URL(url).openConnection();
        try {
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(10_000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Referer", REFERER);
            connection.setRequestProperty("Origin", SITE_ORIGIN);
            connection.setRequestProperty("Accept", "*/*");
            connection.setRequestProperty("Range", "bytes=0-0");

            int responseCode = connection.getResponseCode();
            if (responseCode >= 200 && responseCode <= 399) {
                return true;
            }
            if (responseCode == HttpURLConnection.HTTP_FORBIDDEN
                    || responseCode == HttpURLConnection.HTTP_NOT_FOUND) {
                return false;
            }
            if (responseCode >= 500 && responseCode <= 599) {
                throw new IOException("Serverfehler HTTP " + responseCode);
            }
            return false;
        } finally {
            connection.disconnect();
        }
    }

    private File createPlaylist(
            String videoId,
            int lastSegment
    ) throws IOException {
        StringBuilder playlist = new StringBuilder();
        playlist.append("#EXTM3U\n");
        playlist.append("#EXT-X-VERSION:3\n");
        playlist.append("#EXT-X-PLAYLIST-TYPE:VOD\n");
        playlist.append("#EXT-X-TARGETDURATION:10\n");
        playlist.append("#EXT-X-MEDIA-SEQUENCE:0\n");

        /*
         * The probe anchor is not the beginning of the video. Skill-Capped
         * streams are reconstructed exactly like the supplied browser viewer:
         * every segment from 0 through the discovered final segment.
         */
        for (int index = 0; index <= lastSegment; index++) {
            playlist.append("#EXTINF:10.0,\n");
            playlist.append(segmentUrl(videoId, index)).append('\n');
        }
        playlist.append("#EXT-X-ENDLIST\n");

        File output = new File(getCacheDir(), "generated-stream.m3u8");
        try (FileOutputStream stream = new FileOutputStream(output)) {
            stream.write(
                    playlist.toString().getBytes(StandardCharsets.UTF_8)
            );
        }
        return output;
    }

    private void playHls(Uri uri) {
        Map<String, String> headers = new HashMap<>();
        headers.put("Referer", REFERER);
        headers.put("Origin", SITE_ORIGIN);
        headers.put("Accept", "*/*");

        DefaultHttpDataSource.Factory httpFactory =
                new DefaultHttpDataSource.Factory()
                        .setUserAgent(USER_AGENT)
                        .setAllowCrossProtocolRedirects(true)
                        .setConnectTimeoutMs(15_000)
                        .setReadTimeoutMs(15_000)
                        .setDefaultRequestProperties(headers);

        MediaItem mediaItem = new MediaItem.Builder()
                .setUri(uri)
                .setMimeType(MimeTypes.APPLICATION_M3U8)
                .build();

        DefaultDataSource.Factory dataSourceFactory =
                new DefaultDataSource.Factory(this, httpFactory);
        /*
         * hls.js is tolerant of MPEG-TS segments without explicit access-unit
         * delimiters or strict IDR keyframes. ExoPlayer needs these flags to
         * parse the same streams reliably.
         */
        int tsFlags =
                DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
                        | DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES;
        DefaultHlsExtractorFactory extractorFactory =
                new DefaultHlsExtractorFactory(tsFlags, true);

        HlsMediaSource mediaSource =
                new HlsMediaSource.Factory(dataSourceFactory)
                        .setExtractorFactory(extractorFactory)
                        .createMediaSource(mediaItem);

        player.stop();
        player.clearMediaItems();
        player.setMediaSource(mediaSource);
        player.prepare();
        player.play();
        playerView.showController();
    }

    private String describePlaybackError(PlaybackException error) {
        StringBuilder result = new StringBuilder();
        Throwable current = error;
        int depth = 0;

        while (current != null && depth < 8) {
            String message = current.getMessage();
            if (message != null && !message.trim().isEmpty()) {
                if (result.length() > 0 && result.indexOf(message) >= 0) {
                    current = current.getCause();
                    depth++;
                    continue;
                }
                if (result.length() > 0) {
                    result.append(" → ");
                }
                result.append(current.getClass().getSimpleName())
                        .append(": ")
                        .append(message);
            }
            current = current.getCause();
            depth++;
        }

        if (result.length() == 0) {
            return "Unbekannter Playerfehler";
        }

        final int maximumLength = 420;
        if (result.length() > maximumLength) {
            return result.substring(0, maximumLength) + "…";
        }
        return result.toString();
    }

    private String segmentUrl(String videoId, int index) {
        return CDN_ROOT + "/" + videoId + "/HIDDEN4500-"
                + String.format(Locale.ROOT, "%05d", index) + ".ts";
    }

    private void updateStatus(String message) {
        runOnUiThread(() -> statusText.setText(message));
    }

    private void setLoadingUi(boolean loading, String message) {
        streamButton.setEnabled(!loading);
        progressBar.setVisibility(loading ? View.VISIBLE : View.GONE);
        statusText.setText(message);
    }

    private void finishLoading(String message) {
        isLoading.set(false);
        setLoadingUi(false, message);
    }

    @Override
    protected void onDestroy() {
        playerView.setPlayer(null);
        player.release();
        worker.shutdownNow();
        super.onDestroy();
    }
}
