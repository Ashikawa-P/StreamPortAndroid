# StreamPort Android v1.5

This version keeps the complete segment discovery from v1.4 and fixes the
remaining ExoPlayer MPEG-TS compatibility problem.

Changes:
- Enables FLAG_DETECT_ACCESS_UNITS for TS files without AUD markers.
- Enables FLAG_ALLOW_NON_IDR_KEYFRAMES for TS files without strict IDR frames.
- Uses decoder fallback where the device offers an alternative decoder.
- Shows the complete nested playback error instead of only "Source error".
- Retains ranged GET validation, Referer/Origin headers and the complete
  segment range from 0 through the discovered final segment.
